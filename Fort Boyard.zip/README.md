Documentation du Projet
Présentation Générale
Titre du Projet
Nom du projet : [Fort Boyard ]

Contributeurs
Nom du contributeur 1 : Desnoes Corentin
Nom du contributeur 2 : Ahmed Fhaket

Description
Un bref aperçu du projet : [Le projet était vachement instructif ,nous avons beaucoup appris par rapport à la gestion d'un projet en groupe]

Fonctionnalités Principales de l'Application
Fonctionnalité 1 : [coder]
Fonctionnalité 2 : [partager]
Fonctionnalité 3 : [construire]

Technologies Utilisées
Langages de programmation : [python et console en ligne]
Bibliothèques : [random, json]
Outils : [python , pycharm , github]



Utilisation
Exécuter l'application :
utiliser pycharm et GitHub
pycharm : utilisation python classique avec console
GitHub : permet d'utiliser pycharm à 2

Documentation Technique
Algorithme du Jeu
Étape 1 : [création des épreuves ]
Étape 2 : [création de fonction utile et de l'épreuve finale]
Étape 3 : [création du main code]

Détails des Fonctions Implémentées
Fonction 1
Rôle : [Intro]
Fonction 2
Rôle : [Composer les équipes]
Fonction 3
Rôle : [choisis un jouer pour faire l'épreuve]


---

Journal de Bord
Chronologie du Projet
| Date       | Étape clé                            | Décision/Problème rencontré        |
|------------|-------------------------------       |------------------------------------|
| [20/12/24]   | [création des épreuves]            | [répartition des épreuves]         |
| [02/01/25]   |[créations des fonction et de main] | [répartition des taches]           |


---


## 4. Tests et Validation

Nous avons rencontré des problèmes avec la console pycharm nous avons donc utiliser des consoles en lignes









